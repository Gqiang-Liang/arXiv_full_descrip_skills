# arXiv Dataset Analysis Dimensions Reference

## Data Source

### Primary Source
- **Kaggle**: [Cornell-University/arxiv](https://www.kaggle.com/datasets/Cornell-University/arxiv)
- **HuggingFace Mirror**: `librarian-bots/arxiv-metadata-snapshot` (no credentials needed)
- **Format**: 10 Parquet shards, ~2.7 GB total, ~3.08M papers
- **Time Span**: 1986 - present (updated periodically)

### Alternative Source (API-based, for sampling)
- **arXiv API**: `http://export.arxiv.org/api/query` (rate-limited: 1 request / 3 seconds)
- **OAI-PMH**: `https://oaipmh.arxiv.org/oai` (1300 records per response, resumption token pagination)
- **arxiv Python library**: `pip install arxiv` (wraps the REST API)

## Dataset Schema (14 Fields)

| Field | Type | Description | Completeness |
|-------|------|-------------|-------------|
| `id` | string | arXiv ID (e.g., "0704.0001") | 100% |
| `submitter` | string | Submitter name | 99.5% |
| `authors` | string | Semicolon-separated author names | 100% |
| `title` | string | Paper title | 100% |
| `comments` | string | Free-text comments (pages, figures, etc.) | 72.2% |
| `journal-ref` | string | Journal reference (indicates formal publication) | 30.8% |
| `doi` | string | Digital Object Identifier | 42.7% |
| `report-no` | string | Report number | 6.2% |
| `categories` | string | Space-separated arXiv categories (first = primary) | 100% |
| `license` | string | License type | 85.3% |
| `abstract` | string | Paper abstract | 100% |
| `versions` | JSON array | Version history: `[{"version": "v1", "created": "Sun, 21 Sep 2008 13:33:12 GMT"}]` | 100% |
| `update_date` | datetime | Last update date | 100% |
| `authors_parsed` | JSON array | Parsed authors: `[["last", "first", "suffix"]]` | 100% |

## 13 Analysis Dimensions

### 1. Data Overview
- Total paper count, time span (first/last submission date)
- Field completeness matrix (non-null rates for all 14 fields)
- Data quality assessment

### 2. Submission Time Trends
- **Key parsing**: Extract first submission date from `versions[0]['created']`
  - Format: `"Sun, 21 Sep 2008 13:33:12 GMT"` → parse with `datetime.strptime(s, '%a, %d %b %Y %H:%M:%S GMT')`
- Yearly submission counts (1986-present, 40+ year history)
- Monthly submission counts (year-month granularity)
- Year-over-year (YoY) growth rates
- Historical milestone identification (e.g., COVID-19 impact in 2020)

### 3. Publication Status Analysis (Core Dimension)
- **Published definition**: `doi` OR `journal-ref` is non-null
- **Publication timing** (requires `journal-ref` year parsing):
  - Extract year from `journal-ref` using regex: `r'\b(19[5-9]\d|20[0-4]\d)\b'` (take last match)
  - Compare publication year vs submission year (from `versions[0]`):
    - `pub_year < submit_year` → **published before submission** (journal first, then arXiv)
    - `pub_year == submit_year` → **same-year publication**
    - `pub_year > submit_year` → **published after submission** (arXiv first, then journal)
  - Publication lag distribution (lag = pub_year - submit_year, in years)
- Publication rate by submission year (shows survival bias: recent papers haven't had time to be published)
- **Data limitation**: ~481K published papers have unparseable journal-ref years; regex may produce errors for edge cases

### 4. Category Distribution
- Primary category = first token in `categories` string (space-separated)
- Top 15-20 primary categories with paper counts and publication rates
- Broad category aggregation mapping:
  - `cs*` → Computer Science
  - `math*` → Mathematics
  - `physics/cond-mat/astro-ph/hep/gr-qc/quant-ph/nlin/nucl` → Physics
  - `q-bio*` → Quantitative Biology
  - `q-fin*` → Quantitative Finance
  - `econ*` → Economics
  - `stat*` → Statistics
  - `eess*` → Electrical Engineering

### 5. Interdisciplinary Analysis
- Categories per paper: count tokens in `categories` string
- Multi-category rate (% of papers with >1 category)
- Category count distribution (1, 2, 3, 4, 5+ categories)
- Top 20 most common category combinations

### 6. Author Collaboration Patterns
- Author count: `len(authors_parsed)` per paper
- Descriptive statistics: mean, median, std, min, max, percentiles (Q25, Q75, Q90, Q95, Q99)
- **Memory-efficient quantile estimation**: Sample every 50th row for percentile calculation (avoids loading all 3M values)
- Bucket distribution: 1 author / 2-5 / 6-10 / 11-50 / 50+
- Publication rate by author bucket (correlation between team size and publication)
- **Historical trend**: Average authors per year (1990-present) — shows collaboration growth
- Top 10 largest teams (>500 authors, typically particle physics collaborations)

### 7. Version Update Behavior
- Version count: `len(versions)` array
- Version distribution: v1 (no update) / v2 / v3 / v4 / v5+
- Publication rate by version number (v2 typically has highest publication rate)
- Update rate: % of papers with >1 version
- Update time difference: `versions[-1]['created'] - versions[0]['created']` in days
  - Cap sample at 500K for memory safety
  - Statistics: mean, median, std, Q25, Q75, Q90, max
- Average versions by category (which fields update most frequently)

### 8. Abstract Characteristics
- Word count: `len(abstract.split())` per paper
- Descriptive statistics + bucket distribution (0-100, 101-200, 201-300, 301-500, 500+)
- **Historical trend**: Average abstract length by year (shows secular increase)
- Abstract length by category (astrophysics typically longest)

### 9. Title Characteristics
- Word count: `len(title.split())` per paper
- Descriptive statistics + bucket distribution (0-5, 6-10, 11-15, 16-20, 20+)
- **Publication correlation**: Publication rate by title length bucket (longer titles → higher publication rate)
- Historical trend: Average title length by year

### 10. Cross-Category Publication Rate Differences
- Publication rate per primary category (count >= 1000 for statistical significance)
- Top 20 highest publication rate categories (typically condensed matter physics: 80-85%)
- Bottom 20 lowest publication rate categories (typically CS/econ: 10-15%)
- **Cultural insight**: Physics has strong journal culture (70-85% published), CS relies on conferences (11-15%)

### 11. Seasonality Analysis
- Aggregate submissions by month-of-year (1-12), across all years
- Season index: `month_count / (total / 12)` — values >1 = peak season, <1 = off-season
- Typical pattern: Spring (March-May) and Fall (October) are peaks; Summer (August) and Winter (January) are lows

### 12. Growth Trend Analysis
- YoY growth rate per year
- **Exponential growth model fitting** (1995-2025, log-linear regression):
  - `log(count) = a + b * year`
  - Annual growth rate = b * 100%
  - Doubling time = ln(2) / b years
- 3-year prediction using the fitted model

### 13. License Distribution
- Count by `license` field value
- Top categories: arxiv nonexclusive-distrib/1.0 (~60%), CC BY 4.0 (~18%), unknown (~15%)

## Memory Management Strategy

For processing 3M+ records on limited memory:

1. **Chunked shard processing**: Read one parquet shard (~310K rows, ~330MB) at a time
2. **Column projection**: Only read needed columns (skip `authors` string when `authors_parsed` is available)
3. **Incremental aggregation**: Use Counter/defaultdict accumulators, not list storage
4. **Sampling for quantiles**: Store every Nth value (e.g., every 50th) for percentile estimation
5. **Explicit garbage collection**: `del` + `gc.collect()` after each shard
6. **Cap large lists**: Limit `update_days_list` to 500K samples

## Output JSON Structure

The analysis produces a structured JSON with these top-level keys:
```
overview, by_year, by_month, publish_status, publish_timing,
publish_by_year, pub_lag_distribution, category_distribution,
broad_category, interdisciplinary, author_distribution, author_trend,
top_teams, version_distribution, update_stats, abstract_stats,
title_stats, category_publish_rate, seasonality, growth_analysis,
license_distribution
```

This JSON is directly consumable by dashboard/report generation steps.
