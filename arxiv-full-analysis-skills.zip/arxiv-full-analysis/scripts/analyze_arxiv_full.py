#!/usr/bin/env python3
"""
arXiv Full Metadata Dataset - Comprehensive Multi-Dimensional Statistical Analysis
==================================================================================
Dataset: librarian-bots/arxiv-metadata-snapshot (~3.08M papers)
Strategy: Chunked shard processing + vectorized pandas operations (memory-safe)

Usage:
    python analyze_arxiv_full.py --data-dir <parquet_dir> --output <output.json>

Author: Sage (Data Science Engineer) - arXiv-full-analysis skill
"""

import argparse
import json
import re
import glob
import warnings
import gc
from datetime import datetime
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

warnings.filterwarnings('ignore')

# =============================================================================
# Configuration
# =============================================================================
COLUMNS = ['id', 'doi', 'journal-ref', 'categories', 'abstract', 'title',
           'versions', 'update_date', 'authors_parsed', 'comments', 'license',
           'submitter', 'authors', 'report-no']

ALL_FIELDS = ['id', 'submitter', 'authors', 'title', 'comments', 'journal-ref',
              'doi', 'report-no', 'categories', 'license', 'abstract', 'versions',
              'update_date', 'authors_parsed']

BROAD_CATS = {
    'cs': 'Computer Science', 'math': 'Mathematics', 'physics': 'Physics',
    'cond-mat': 'Physics', 'astro-ph': 'Physics', 'hep': 'Physics',
    'gr-qc': 'Physics', 'quant-ph': 'Physics', 'nlin': 'Physics',
    'nucl': 'Physics', 'acc-phys': 'Physics', 'physics': 'Physics',
    'q-bio': 'Quantitative Biology', 'q-fin': 'Quantitative Finance',
    'econ': 'Economics', 'stat': 'Statistics', 'eess': 'Electrical Engineering',
}

# Matches years 1950-2049 in journal-ref strings
YEAR_RE = re.compile(r'\b(19[5-9]\d|20[0-4]\d)\b')


def get_broad_category(primary_cat):
    """Map a specific arXiv category to its broad discipline."""
    if not primary_cat or primary_cat == 'unknown':
        return 'Other'
    for key in BROAD_CATS:
        if primary_cat.startswith(key):
            return BROAD_CATS[key]
    if '.' in primary_cat:
        prefix = primary_cat.split('.')[0]
        if prefix in BROAD_CATS:
            return BROAD_CATS[prefix]
    return 'Other'


def parse_created_date(created_str):
    """Parse arXiv OAI date format: 'Sun, 21 Sep 2008 13:33:12 GMT'."""
    if not created_str or (isinstance(created_str, float) and np.isnan(created_str)):
        return None
    try:
        return datetime.strptime(str(created_str), '%a, %d %b %Y %H:%M:%S GMT')
    except (ValueError, TypeError):
        return None


def extract_year_from_jref(jref):
    """Extract publication year from journal-ref string using regex."""
    if not jref or (isinstance(jref, float) and np.isnan(jref)):
        return None
    matches = YEAR_RE.findall(str(jref))
    if matches:
        return int(matches[-1])  # Take last year match (usually the pub year)
    return None


def safe_len(x):
    """Safe length function that handles None, NaN, and non-iterable values."""
    if x is None:
        return 0
    try:
        if isinstance(x, float) and np.isnan(x):
            return 0
        return len(x)
    except:
        return 0


def main():
    parser = argparse.ArgumentParser(description='arXiv full dataset multi-dimensional analysis')
    parser.add_argument('--data-dir', required=True,
                        help='Directory containing parquet shards (glob pattern: <dir>/*/data/*.parquet)')
    parser.add_argument('--output', required=True,
                        help='Output JSON file path for summary statistics')
    args = parser.parse_args()

    parquet_files = sorted(glob.glob(f'{args.data_dir}/*/data/*.parquet'))
    if not parquet_files:
        # Try direct glob pattern
        parquet_files = sorted(glob.glob(f'{args.data_dir}/*.parquet'))
    if not parquet_files:
        print(f'ERROR: No parquet files found in {args.data_dir}')
        return

    print(f'Found {len(parquet_files)} parquet shards')
    print(f'Output: {args.output}')
    start_time = datetime.now()

    # ... [rest of the analysis logic is identical to the original script]
    # The full implementation is in the bundled reference: references/analysis_dimensions.md

    # Aggregation state
    total_papers = 0
    field_nonnull = Counter()
    min_submit_date = None
    max_submit_date = None
    min_update_date = None
    max_update_date = None
    yearly_counts = Counter()
    monthly_counts = Counter()
    month_of_year_counts = Counter()
    published_count = 0
    unpublished_count = 0
    pub_timing = Counter()
    pub_by_year = defaultdict(lambda: {'total': 0, 'published': 0})
    pub_lag_dist = Counter()
    cat_counts = Counter()
    cat_published = Counter()
    broad_cat_counts = Counter()
    broad_cat_published = Counter()
    total_categories_sum = 0
    cat_count_dist = Counter()
    cat_combinations = Counter()
    author_sum = 0
    author_count_sq_sum = 0
    author_min = float('inf')
    author_max = 0
    author_buckets = Counter()
    author_pub_buckets = defaultdict(lambda: {'total': 0, 'published': 0})
    author_by_year = defaultdict(lambda: {'sum': 0, 'count': 0})
    top_teams = []
    author_sample = []
    version_dist = Counter()
    version_pub = defaultdict(lambda: {'total': 0, 'published': 0})
    update_days_list = []
    updated_count = 0
    not_updated_count = 0
    version_by_cat = defaultdict(lambda: {'sum': 0, 'count': 0})
    abstract_sum = 0
    abstract_sq_sum = 0
    abstract_min = float('inf')
    abstract_max = 0
    abstract_buckets = Counter()
    abstract_by_year = defaultdict(lambda: {'sum': 0, 'count': 0})
    abstract_by_cat = defaultdict(lambda: {'sum': 0, 'count': 0})
    abstract_sample = []
    title_sum = 0
    title_sq_sum = 0
    title_min = float('inf')
    title_max = 0
    title_buckets = Counter()
    title_by_year = defaultdict(lambda: {'sum': 0, 'count': 0})
    title_pub_buckets = defaultdict(lambda: {'total': 0, 'published': 0})
    license_counts = Counter()

    # Process each shard
    for shard_idx, fpath in enumerate(parquet_files):
        shard_start = datetime.now()
        print(f'\n[Shard {shard_idx+1}/{len(parquet_files)}] {fpath.split("/")[-1]}...')

        table = pq.read_table(fpath, columns=COLUMNS)
        df = table.to_pandas()
        n = len(df)
        total_papers += n

        # 1. Field non-null counts
        for field in ALL_FIELDS:
            if field in df.columns:
                field_nonnull[field] += int(df[field].notna().sum())

        # Parse versions
        def parse_versions_row(vlist):
            vc = safe_len(vlist)
            if vc == 0:
                return (None, None, 0)
            try:
                first_c = vlist[0]
                last_c = vlist[-1]
                fd = parse_created_date(first_c['created']) if isinstance(first_c, dict) else None
                ld = parse_created_date(last_c['created']) if isinstance(last_c, dict) else None
                return (fd, ld, vc)
            except:
                return (None, None, vc)

        versions_parsed = df['versions'].apply(parse_versions_row)
        first_dates = versions_parsed.apply(lambda x: x[0])
        last_dates = versions_parsed.apply(lambda x: x[1])
        version_counts = versions_parsed.apply(lambda x: x[2])

        # Update date range
        ud_valid = df['update_date'].dropna()
        if len(ud_valid) > 0:
            ud_min = ud_valid.min()
            ud_max = ud_valid.max()
            if min_update_date is None or ud_min < min_update_date:
                min_update_date = ud_min
            if max_update_date is None or ud_max > max_update_date:
                max_update_date = ud_max

        # 2. Submission time trends
        fd_valid_mask = first_dates.notna()
        fd_valid = first_dates[fd_valid_mask]
        for fd in fd_valid:
            if min_submit_date is None or fd < min_submit_date:
                min_submit_date = fd
            if max_submit_date is None or fd > max_submit_date:
                max_submit_date = fd
            yearly_counts[fd.year] += 1
            monthly_counts[(fd.year, fd.month)] += 1
            month_of_year_counts[fd.month] += 1

        # 3. Publish status
        doi_nonnull = df['doi'].notna()
        jref_nonnull = df['journal-ref'].notna()
        is_published = doi_nonnull | jref_nonnull
        published_count += int(is_published.sum())
        unpublished_count += int((~is_published).sum())

        jref_years = df['journal-ref'].apply(extract_year_from_jref)
        submit_years = first_dates.apply(lambda x: x.year if x is not None else None)

        pub_mask = is_published.values
        sy_arr = submit_years.values
        jy_arr = jref_years.values

        for i in range(n):
            sy = sy_arr[i]
            jy = jy_arr[i]
            pub = pub_mask[i]
            if sy is not None:
                pub_by_year[sy]['total'] += 1
                if pub:
                    pub_by_year[sy]['published'] += 1
            if pub and sy is not None and jy is not None:
                lag = jy - sy
                if lag < 0:
                    pub_timing['before_submission'] += 1
                elif lag > 0:
                    pub_timing['after_submission'] += 1
                else:
                    pub_timing['same_year'] += 1
                pub_lag_dist[lag] += 1
            elif pub:
                pub_timing['unknown'] += 1

        # 4 & 5. Categories
        cats_split = df['categories'].fillna('').apply(lambda x: str(x).split() if x else [])
        primary_cats = cats_split.apply(lambda x: x[0] if x else 'unknown')
        cat_counts_list = cats_split.apply(len)
        pub_arr = is_published.values
        prim_arr = primary_cats.values
        ncat_arr = cat_counts_list.values

        for i in range(n):
            prim = prim_arr[i]
            pub = bool(pub_arr[i])
            ncat = ncat_arr[i]
            cat_counts[prim] += 1
            broad = get_broad_category(prim)
            broad_cat_counts[broad] += 1
            if pub:
                cat_published[prim] += 1
                broad_cat_published[broad] += 1
            total_categories_sum += ncat
            if ncat <= 4:
                cat_count_dist[ncat] += 1
            else:
                cat_count_dist['5+'] += 1
            if ncat > 1:
                cat_combinations[df['categories'].iloc[i]] += 1
            vc = version_counts.iloc[i]
            version_by_cat[prim]['sum'] += vc
            version_by_cat[prim]['count'] += 1

        # 6. Authors
        author_counts = df['authors_parsed'].apply(safe_len)
        ac_arr = author_counts.values
        author_sum += int(author_counts.sum())
        author_count_sq_sum += int((author_counts ** 2).sum())
        author_min = min(author_min, int(author_counts.min()))
        author_max = max(author_max, int(author_counts.max()))
        for i in range(0, n, 50):
            author_sample.append(int(ac_arr[i]))

        def author_bucket(na):
            if na == 1: return '1'
            elif na <= 5: return '2-5'
            elif na <= 10: return '6-10'
            elif na <= 50: return '11-50'
            else: return '50+'

        abuckets = author_counts.apply(author_bucket)
        for i in range(n):
            bucket = abuckets.iloc[i]
            pub = bool(pub_arr[i])
            author_buckets[bucket] += 1
            author_pub_buckets[bucket]['total'] += 1
            if pub:
                author_pub_buckets[bucket]['published'] += 1
            sy = sy_arr[i]
            if sy is not None:
                author_by_year[sy]['sum'] += int(ac_arr[i])
                author_by_year[sy]['count'] += 1
            na = int(ac_arr[i])
            if na > 500:
                title = df['title'].iloc[i]
                paper_id = df['id'].iloc[i]
                top_teams.append((na, str(title)[:100] if title and not pd.isna(title) else '', str(paper_id), prim_arr[i]))

        # 7. Version distribution
        vc_arr = version_counts.values
        for i in range(n):
            vc = int(vc_arr[i])
            if vc == 1: vb = 'v1'
            elif vc == 2: vb = 'v2'
            elif vc == 3: vb = 'v3'
            elif vc == 4: vb = 'v4'
            else: vb = 'v5+'
            version_dist[vb] += 1
            pub = bool(pub_arr[i])
            version_pub[vb]['total'] += 1
            if pub:
                version_pub[vb]['published'] += 1
            if vc > 1:
                updated_count += 1
            else:
                not_updated_count += 1

        for i in range(n):
            vc = int(vc_arr[i])
            if vc > 1:
                fd = first_dates.iloc[i]
                ld = last_dates.iloc[i]
                if fd is not None and ld is not None and len(update_days_list) < 500000:
                    delta = (ld - fd).days
                    if delta >= 0:
                        update_days_list.append(delta)

        # 8. Abstract stats
        abstract_wc = df['abstract'].fillna('').apply(lambda x: len(str(x).split()))
        awc_arr = abstract_wc.values
        abstract_sum += int(abstract_wc.sum())
        abstract_sq_sum += int((abstract_wc ** 2).sum())
        abstract_min = min(abstract_min, int(abstract_wc.min()))
        abstract_max = max(abstract_max, int(abstract_wc.max()))
        for i in range(0, n, 50):
            abstract_sample.append(int(awc_arr[i]))

        def abs_bucket(wc):
            if wc == 0: return '0'
            elif wc <= 100: return '0-100'
            elif wc <= 200: return '101-200'
            elif wc <= 300: return '201-300'
            elif wc <= 500: return '301-500'
            else: return '500+'

        abs_bk = abstract_wc.apply(abs_bucket)
        for i in range(n):
            abstract_buckets[abs_bk.iloc[i]] += 1
            sy = sy_arr[i]
            if sy is not None:
                abstract_by_year[sy]['sum'] += int(awc_arr[i])
                abstract_by_year[sy]['count'] += 1
            abstract_by_cat[prim_arr[i]]['sum'] += int(awc_arr[i])
            abstract_by_cat[prim_arr[i]]['count'] += 1

        # 9. Title stats
        title_wc = df['title'].fillna('').apply(lambda x: len(str(x).split()))
        twc_arr = title_wc.values
        title_sum += int(title_wc.sum())
        title_sq_sum += int((title_wc ** 2).sum())
        title_min = min(title_min, int(title_wc.min()))
        title_max = max(title_max, int(title_wc.max()))

        def title_bucket(wc):
            if wc <= 5: return '0-5'
            elif wc <= 10: return '6-10'
            elif wc <= 15: return '11-15'
            elif wc <= 20: return '16-20'
            else: return '20+'

        tit_bk = title_wc.apply(title_bucket)
        for i in range(n):
            bucket = tit_bk.iloc[i]
            pub = bool(pub_arr[i])
            title_buckets[bucket] += 1
            title_pub_buckets[bucket]['total'] += 1
            if pub:
                title_pub_buckets[bucket]['published'] += 1
            sy = sy_arr[i]
            if sy is not None:
                title_by_year[sy]['sum'] += int(twc_arr[i])
                title_by_year[sy]['count'] += 1

        # 13. License
        lic_vals = df['license'].fillna('unknown')
        for lic in lic_vals:
            license_counts[str(lic)] += 1

        # Cleanup
        del df, table, versions_parsed, first_dates, last_dates, version_counts
        del doi_nonnull, jref_nonnull, is_published, jref_years, submit_years
        del cats_split, primary_cats, cat_counts_list, author_counts, abuckets
        del abstract_wc, abs_bk, title_wc, tit_bk, lic_vals
        gc.collect()

        elapsed = (datetime.now() - shard_start).total_seconds()
        print(f'  -> {n:,} rows | cumulative: {total_papers:,} | time: {elapsed:.1f}s')

    total_elapsed = (datetime.now() - start_time).total_seconds()
    print(f'\nTotal papers: {total_papers:,} | Total time: {total_elapsed:.1f}s')
    print('Building summary JSON...')

    # Build summary JSON (identical to original script)
    summary = build_summary(
        total_papers, field_nonnull, min_submit_date, max_submit_date,
        min_update_date, max_update_date, yearly_counts, monthly_counts,
        month_of_year_counts, published_count, unpublished_count, pub_timing,
        pub_by_year, pub_lag_dist, cat_counts, cat_published, broad_cat_counts,
        broad_cat_published, total_categories_sum, cat_count_dist, cat_combinations,
        author_sum, author_count_sq_sum, author_min, author_max, author_buckets,
        author_pub_buckets, author_by_year, top_teams, author_sample,
        version_dist, version_pub, update_days_list, updated_count, not_updated_count,
        version_by_cat, abstract_sum, abstract_sq_sum, abstract_min, abstract_max,
        abstract_buckets, abstract_by_year, abstract_by_cat, abstract_sample,
        title_sum, title_sq_sum, title_min, title_max, title_buckets,
        title_by_year, title_pub_buckets, license_counts
    )

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)

    json_size = round(len(json.dumps(summary, default=str)) / 1024 / 1024, 2)
    print(f'\nSummary JSON saved to: {args.output}')
    print(f'JSON file size: {json_size} MB')
    print(f'\n{"=" * 80}')
    print(f'ANALYSIS COMPLETE - {total_papers:,} papers in {total_elapsed:.1f}s')
    print(f'{"=" * 80}')


def build_summary(total_papers, field_nonnull, min_submit_date, max_submit_date,
                  min_update_date, max_update_date, yearly_counts, monthly_counts,
                  month_of_year_counts, published_count, unpublished_count, pub_timing,
                  pub_by_year, pub_lag_dist, cat_counts, cat_published, broad_cat_counts,
                  broad_cat_published, total_categories_sum, cat_count_dist, cat_combinations,
                  author_sum, author_count_sq_sum, author_min, author_max, author_buckets,
                  author_pub_buckets, author_by_year, top_teams, author_sample,
                  version_dist, version_pub, update_days_list, updated_count, not_updated_count,
                  version_by_cat, abstract_sum, abstract_sq_sum, abstract_min, abstract_max,
                  abstract_buckets, abstract_by_year, abstract_by_cat, abstract_sample,
                  title_sum, title_sq_sum, title_min, title_max, title_buckets,
                  title_by_year, title_pub_buckets, license_counts):
    """Build the complete summary JSON from aggregated statistics."""

    summary = {}

    # 1. Overview
    completeness = {}
    for field in ALL_FIELDS:
        nn = field_nonnull.get(field, 0)
        completeness[field] = {
            'non_null': nn, 'null': total_papers - nn,
            'non_null_rate': round(nn / total_papers * 100, 2) if total_papers else 0
        }
    summary['overview'] = {
        'total_papers': total_papers,
        'date_range': {
            'first_submission': min_submit_date.isoformat() if min_submit_date else None,
            'last_submission': max_submit_date.isoformat() if max_submit_date else None,
            'first_update': min_update_date.isoformat() if min_update_date and hasattr(min_update_date, 'isoformat') else str(min_update_date),
            'last_update': max_update_date.isoformat() if max_update_date and hasattr(max_update_date, 'isoformat') else str(max_update_date),
        },
        'completeness': completeness,
    }

    # 2. Time trends
    summary['by_year'] = [{'year': y, 'count': yearly_counts[y]} for y in sorted(yearly_counts.keys())]
    summary['by_month'] = [{'year_month': f"{y}-{m:02d}", 'count': monthly_counts[(y, m)]} for (y, m) in sorted(monthly_counts.keys())]

    # 3. Publish status
    summary['publish_status'] = {
        'published': published_count, 'unpublished': unpublished_count,
        'publish_rate': round(published_count / total_papers * 100, 2),
    }
    summary['publish_timing'] = dict(pub_timing)
    summary['publish_by_year'] = [
        {'year': y, 'total': pub_by_year[y]['total'], 'published': pub_by_year[y]['published'],
         'publish_rate': round(pub_by_year[y]['published'] / pub_by_year[y]['total'] * 100, 2) if pub_by_year[y]['total'] else 0}
        for y in sorted(pub_by_year.keys())
    ]
    summary['pub_lag_distribution'] = [{'lag_years': lag, 'count': pub_lag_dist[lag]} for lag in sorted(pub_lag_dist.keys())]

    # 4. Category distribution
    summary['category_distribution'] = [
        {'category': cat, 'count': cat_counts[cat], 'published': cat_published.get(cat, 0),
         'publish_rate': round(cat_published.get(cat, 0) / cat_counts[cat] * 100, 2) if cat_counts[cat] else 0}
        for cat in sorted(cat_counts.keys(), key=lambda x: cat_counts[x], reverse=True)
    ]
    summary['broad_category'] = [
        {'category': cat, 'count': broad_cat_counts[cat],
         'publish_rate': round(broad_cat_published.get(cat, 0) / broad_cat_counts[cat] * 100, 2) if broad_cat_counts[cat] else 0}
        for cat in sorted(broad_cat_counts.keys(), key=lambda x: broad_cat_counts[x], reverse=True)
    ]

    # 5. Interdisciplinary
    avg_cats = round(total_categories_sum / total_papers, 3) if total_papers else 0
    multi_count = sum(v for k, v in cat_count_dist.items() if k not in (1, '1', 0, '0'))
    summary['interdisciplinary'] = {
        'avg_categories': avg_cats,
        'multi_rate': round(multi_count / total_papers * 100, 2) if total_papers else 0,
        'distribution': [{'n_categories': k, 'count': v} for k, v in sorted(cat_count_dist.items(), key=lambda x: str(x[0]))],
        'top_combinations': [{'combination': c, 'count': cnt} for c, cnt in cat_combinations.most_common(20)]
    }

    # 6. Authors
    author_mean = round(author_sum / total_papers, 2) if total_papers else 0
    author_var = (author_count_sq_sum / total_papers - (author_sum / total_papers) ** 2) if total_papers else 0
    author_std = round(np.sqrt(max(author_var, 0)), 2)
    if author_sample:
        ac_arr = np.array(author_sample)
        author_median = int(np.median(ac_arr))
        author_q25, author_q75 = int(np.percentile(ac_arr, 25)), int(np.percentile(ac_arr, 75))
        author_q90, author_q95, author_q99 = int(np.percentile(ac_arr, 90)), int(np.percentile(ac_arr, 95)), int(np.percentile(ac_arr, 99))
    else:
        author_median = author_q25 = author_q75 = author_q90 = author_q95 = author_q99 = 0

    summary['author_distribution'] = {
        'stats': {'mean': author_mean, 'median': author_median, 'std': author_std,
                  'min': int(author_min) if author_min != float('inf') else 0, 'max': int(author_max),
                  'q25': author_q25, 'q75': author_q75, 'q90': author_q90, 'q95': author_q95, 'q99': author_q99,
                  'sample_size': len(author_sample)},
        'buckets': [
            {'bucket': b, 'count': author_buckets.get(b, 0),
             'publish_rate': round(author_pub_buckets[b]['published'] / author_pub_buckets[b]['total'] * 100, 2) if author_pub_buckets[b]['total'] else 0}
            for b in ['1', '2-5', '6-10', '11-50', '50+']
        ],
    }
    summary['author_trend'] = [
        {'year': y, 'avg_authors': round(author_by_year[y]['sum'] / author_by_year[y]['count'], 2) if author_by_year[y]['count'] else 0}
        for y in sorted(author_by_year.keys())
    ]
    top_teams.sort(reverse=True)
    summary['top_teams'] = [{'authors': t[0], 'title': t[1], 'id': t[2], 'category': t[3]} for t in top_teams[:10]]

    # 7. Versions
    summary['version_distribution'] = [
        {'versions': vb, 'count': version_dist.get(vb, 0),
         'publish_rate': round(version_pub[vb]['published'] / version_pub[vb]['total'] * 100, 2) if version_pub[vb]['total'] else 0}
        for vb in ['v1', 'v2', 'v3', 'v4', 'v5+']
    ]
    if update_days_list:
        ud_arr = np.array(update_days_list)
        update_days_stats = {'count': len(update_days_list), 'mean': round(float(np.mean(ud_arr)), 1),
                             'median': int(np.median(ud_arr)), 'std': round(float(np.std(ud_arr)), 1),
                             'q25': int(np.percentile(ud_arr, 25)), 'q75': int(np.percentile(ud_arr, 75)),
                             'q90': int(np.percentile(ud_arr, 90)), 'max': int(np.max(ud_arr))}
    else:
        update_days_stats = {}
    summary['update_stats'] = {
        'updated_rate': round(updated_count / total_papers * 100, 2) if total_papers else 0,
        'not_updated_rate': round(not_updated_count / total_papers * 100, 2) if total_papers else 0,
        'update_days_stats': update_days_stats,
        'by_category': [
            {'category': cat, 'avg_versions': round(version_by_cat[cat]['sum'] / version_by_cat[cat]['count'], 3) if version_by_cat[cat]['count'] else 0, 'count': version_by_cat[cat]['count']}
            for cat in sorted(version_by_cat.keys(), key=lambda x: version_by_cat[x]['sum'] / max(version_by_cat[x]['count'], 1), reverse=True)[:20]
        ]
    }

    # 8. Abstract
    abstract_mean = round(abstract_sum / total_papers, 2) if total_papers else 0
    abstract_var = (abstract_sq_sum / total_papers - (abstract_sum / total_papers) ** 2) if total_papers else 0
    abstract_std = round(np.sqrt(max(abstract_var, 0)), 2)
    if abstract_sample:
        as_arr = np.array(abstract_sample)
        abs_median, abs_q25, abs_q75 = int(np.median(as_arr)), int(np.percentile(as_arr, 25)), int(np.percentile(as_arr, 75))
    else:
        abs_median = abs_q25 = abs_q75 = 0
    summary['abstract_stats'] = {
        'overall': {'mean': abstract_mean, 'median': abs_median, 'std': abstract_std,
                    'min': int(abstract_min) if abstract_min != float('inf') else 0, 'max': int(abstract_max),
                    'q25': abs_q25, 'q75': abs_q75},
        'buckets': [{'bucket': b, 'count': abstract_buckets.get(b, 0)} for b in ['0', '0-100', '101-200', '201-300', '301-500', '500+']],
        'by_year_trend': [{'year': y, 'avg_words': round(abstract_by_year[y]['sum'] / abstract_by_year[y]['count'], 1) if abstract_by_year[y]['count'] else 0} for y in sorted(abstract_by_year.keys())],
        'by_category': [{'category': cat, 'avg_words': round(abstract_by_cat[cat]['sum'] / abstract_by_cat[cat]['count'], 1) if abstract_by_cat[cat]['count'] else 0, 'count': abstract_by_cat[cat]['count']} for cat in sorted(abstract_by_cat.keys(), key=lambda x: abstract_by_cat[x]['sum'] / max(abstract_by_cat[x]['count'], 1), reverse=True)[:20]],
    }

    # 9. Title
    title_mean = round(title_sum / total_papers, 2) if total_papers else 0
    title_var = (title_sq_sum / total_papers - (title_sum / total_papers) ** 2) if total_papers else 0
    title_std = round(np.sqrt(max(title_var, 0)), 2)
    summary['title_stats'] = {
        'overall': {'mean': title_mean, 'std': title_std, 'min': int(title_min) if title_min != float('inf') else 0, 'max': int(title_max)},
        'buckets': [{'bucket': b, 'count': title_buckets.get(b, 0)} for b in ['0-5', '6-10', '11-15', '16-20', '20+']],
        'by_year_trend': [{'year': y, 'avg_words': round(title_by_year[y]['sum'] / title_by_year[y]['count'], 1) if title_by_year[y]['count'] else 0} for y in sorted(title_by_year.keys())],
        'publish_correlation': [
            {'bucket': tb, 'count': title_pub_buckets[tb]['total'],
             'publish_rate': round(title_pub_buckets[tb]['published'] / title_pub_buckets[tb]['total'] * 100, 2) if title_pub_buckets[tb]['total'] else 0}
            for tb in ['0-5', '6-10', '11-15', '16-20', '20+']
        ],
    }

    # 10. Category publish rate
    cat_pr_all = [{'category': cat, 'count': cat_counts[cat],
                   'publish_rate': round(cat_published.get(cat, 0) / cat_counts[cat] * 100, 2)}
                  for cat in cat_counts if cat_counts[cat] >= 1000]
    cat_pr_all.sort(key=lambda x: x['publish_rate'], reverse=True)
    summary['category_publish_rate'] = {'top': cat_pr_all[:20], 'bottom': list(reversed(cat_pr_all[-20:]))}

    # 11. Seasonality
    total_monthly = sum(month_of_year_counts.values())
    summary['seasonality'] = [
        {'month': m, 'count': month_of_year_counts.get(m, 0),
         'pct': round(month_of_year_counts.get(m, 0) / total_monthly * 100, 2) if total_monthly else 0,
         'season_index': round(month_of_year_counts.get(m, 0) / (total_monthly / 12), 3) if total_monthly else 0}
        for m in range(1, 13)
    ]

    # 12. Growth analysis
    yoy_growth = []
    sorted_years = sorted(yearly_counts.keys())
    for i, y in enumerate(sorted_years):
        if i == 0:
            yoy_growth.append({'year': y, 'count': yearly_counts[y], 'yoy_rate': None})
        else:
            prev = yearly_counts[sorted_years[i-1]]
            rate = round((yearly_counts[y] - prev) / prev * 100, 2) if prev > 0 else None
            yoy_growth.append({'year': y, 'count': yearly_counts[y], 'yoy_rate': rate})

    growth_years = [y for y in sorted_years if 1995 <= y <= 2025 and yearly_counts[y] > 0]
    if len(growth_years) >= 5:
        counts_arr = np.array([yearly_counts[y] for y in growth_years])
        years_arr = np.array(growth_years)
        log_counts = np.log(counts_arr)
        coeffs = np.polyfit(years_arr, log_counts, 1)
        b, a = coeffs
        summary['growth_analysis'] = {
            'yoy_growth': yoy_growth,
            'growth_model': {'model': 'exponential (log-linear)', 'annual_growth_rate_pct': round(b * 100, 2),
                             'doubling_time_years': round(np.log(2) / b, 2) if b > 0 else None, 'fit_years': f"{growth_years[0]}-{growth_years[-1]}"},
            'prediction': [{'year': y, 'predicted_count': int(np.exp(a + b * y))} for y in [2026, 2027, 2028]]
        }
    else:
        summary['growth_analysis'] = {'yoy_growth': yoy_growth, 'growth_model': {}, 'prediction': []}

    # 13. License
    summary['license_distribution'] = [{'license': k, 'count': v, 'pct': round(v / total_papers * 100, 4)} for k, v in license_counts.most_common(20)]

    return summary


if __name__ == '__main__':
    main()
