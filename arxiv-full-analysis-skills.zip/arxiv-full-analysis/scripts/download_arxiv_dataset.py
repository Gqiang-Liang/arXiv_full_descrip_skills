#!/usr/bin/env python3
"""
Download arXiv full metadata dataset from HuggingFace (Kaggle Cornell-University/arxiv mirror).

This script downloads all parquet shards from the librarian-bots/arxiv-metadata-snapshot
dataset on HuggingFace, which is a mirror of the Kaggle Cornell-University/arxiv dataset.
No credentials required - HuggingFace public datasets are freely accessible.

Usage:
    python download_arxiv_dataset.py --output <cache_dir>

Author: Sage (Data Science Engineer) - arXiv-full-analysis skill
"""

import argparse
import os
from huggingface_hub import hf_hub_download


def main():
    parser = argparse.ArgumentParser(description='Download arXiv full metadata from HuggingFace')
    parser.add_argument('--output', default='./hf_cache',
                        help='Output cache directory (default: ./hf_cache)')
    parser.add_argument('--repo-id', default='librarian-bots/arxiv-metadata-snapshot',
                        help='HuggingFace dataset repo ID (default: librarian-bots/arxiv-metadata-snapshot)')
    parser.add_argument('--num-shards', type=int, default=10,
                        help='Number of parquet shards to download (default: 10)')
    args = parser.parse_args()

    cache_dir = os.path.abspath(args.output)
    os.makedirs(cache_dir, exist_ok=True)

    print(f'Downloading arXiv metadata dataset')
    print(f'  Repo: {args.repo_id}')
    print(f'  Cache: {cache_dir}')
    print(f'  Shards: {args.num_shards}')
    print()

    paths = []
    total_size = 0

    for i in range(args.num_shards):
        filename = f'data/train-{i:05d}-of-{args.num_shards:05d}.parquet'
        print(f'Downloading shard {i+1}/{args.num_shards}: {filename}...', flush=True)

        path = hf_hub_download(
            repo_id=args.repo_id,
            filename=filename,
            repo_type='dataset',
            cache_dir=cache_dir
        )
        size_mb = os.path.getsize(path) / 1024 / 1024
        total_size += size_mb
        print(f'  Done: {size_mb:.1f} MB -> {path}', flush=True)
        paths.append(path)

    print(f'\nAll {args.num_shards} shards downloaded successfully!')
    print(f'Total size: {total_size:.1f} MB ({total_size/1024:.2f} GB)')
    print(f'Data directory: {cache_dir}')

    # Save paths for the analysis script
    paths_file = os.path.join(cache_dir, 'parquet_paths.txt')
    with open(paths_file, 'w') as f:
        for p in paths:
            f.write(p + '\n')
    print(f'Paths saved to: {paths_file}')

    # Print the data-dir argument for the analysis script
    snapshot_dir = os.path.dirname(os.path.dirname(paths[0]))
    print(f'\nTo run analysis:')
    print(f'  python analyze_arxiv_full.py --data-dir "{snapshot_dir}" --output analysis_summary.json')


if __name__ == '__main__':
    main()
