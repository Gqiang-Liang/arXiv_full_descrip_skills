---
name: arxiv-full-analysis
description: "End-to-end workflow for acquiring and analyzing the complete arXiv paper metadata dataset (~3 million papers, 1986-present). This skill should be used when the user wants to perform comprehensive statistical analysis of arXiv papers, including submission trends, publication status (pre/post-submission publication timing), category distribution, author collaboration patterns, version update behavior, abstract/title characteristics, seasonality, and growth modeling. Covers data acquisition (HuggingFace mirror of Kaggle Cornell-University/arxiv, no credentials needed), memory-efficient chunked processing of large Parquet files, 13-dimension statistical analysis, and team-based orchestration for dashboard/report generation. Also applicable to similar large-scale academic metadata datasets with analogous schema (versions, categories, journal-ref, authors_parsed fields)."
agent_created: true
---

# arXiv Full Metadata Analysis Workflow

## Overview

This skill provides a complete workflow for acquiring and analyzing the arXiv full
metadata dataset (~3.08 million papers spanning 1986-present). It handles data
acquisition from HuggingFace (no Kaggle credentials required), memory-efficient
processing of 2.7 GB of Parquet data across 10 shards, 13-dimension statistical
analysis, and team orchestration for visualization and report generation.

## When to Use

- User requests analysis of arXiv papers, especially "all papers" or full corpus analysis
- User mentions arXiv metadata, publication timing, submission trends, or category distribution
- User references the Kaggle Cornell-University/arxiv dataset
- User wants to analyze pre/post-submission publication patterns
- User needs growth modeling or trend prediction for academic preprint submissions
- Similar large-scale academic metadata datasets with analogous schema

## Workflow

### Phase 0: Data Acquisition

Download the full dataset from HuggingFace (mirror of Kaggle Cornell-University/arxiv).

**Script**: `scripts/download_arxiv_dataset.py`

```bash
# Ensure pyarrow and huggingface_hub are installed
pip install pyarrow huggingface_hub pandas numpy

# Download all 10 parquet shards (~2.7 GB, ~3.08M papers)
python scripts/download_arxiv_dataset.py --output ./hf_cache
```

**Key details**:
- HuggingFace repo: `librarian-bots/arxiv-metadata-snapshot`
- No credentials needed (public dataset)
- 10 Parquet shards, ~330 MB each, ~310K rows per shard
- The script prints the `--data-dir` path to pass to the analysis script

**Alternative: arXiv API sampling** (for smaller-scale analysis):
- API endpoint: `http://export.arxiv.org/api/query`
- Rate limit: 1 request per 3 seconds (strict)
- Python library: `pip install arxiv`
- Suitable for samples of 5,000-10,000 papers across selected categories
- NOT suitable for full-corpus analysis (would take 10+ hours)

### Phase 1: Multi-Dimensional Statistical Analysis

Run the analysis script on the downloaded Parquet shards.

**Script**: `scripts/analyze_arxiv_full.py`

```bash
python scripts/analyze_arxiv_full.py \
    --data-dir "<snapshot_dir>" \
    --output analysis_summary.json
```

**Memory management strategy** (critical for 3M+ records):
1. Process one Parquet shard at a time (~310K rows, ~330 MB per shard)
2. Use column projection: only read needed columns
3. Incremental aggregation with Counter/defaultdict (no full DataFrame retention)
4. Sample every 50th row for percentile estimation
5. Cap large lists (e.g., update_days) at 500K samples
6. Explicit `del` + `gc.collect()` after each shard

**Analysis dimensions** (13 total):

| # | Dimension | Key Fields Used | Key Insight |
|---|-----------|----------------|-------------|
| 1 | Data overview | All | Field completeness matrix |
| 2 | Submission time trends | `versions[0].created` | 40-year history, exponential growth |
| 3 | Publication status | `doi`, `journal-ref`, `versions[0].created` | Pre/post-submission publication timing |
| 4 | Category distribution | `categories` (first token = primary) | Top 15 + broad category aggregation |
| 5 | Interdisciplinary | `categories` (token count) | Multi-category rate, common combinations |
| 6 | Author collaboration | `authors_parsed` (array length) | Team size trends, publication correlation |
| 7 | Version updates | `versions` (array length + dates) | Update rate, v2 has highest publication rate |
| 8 | Abstract characteristics | `abstract` (word count) | Secular lengthening trend |
| 9 | Title characteristics | `title` (word count) | Longer titles → higher publication rate |
| 10 | Category publication rates | `categories` + `doi`/`journal-ref` | Physics 70-85% vs CS 11-15% |
| 11 | Seasonality | `versions[0].created` (month) | May peak, August trough |
| 12 | Growth modeling | Yearly counts | Exponential fit, 9.1% annual growth |
| 13 | License distribution | `license` | 60% arXiv non-exclusive, 18% CC BY 4.0 |

**Critical field parsing logic**:

- **First submission date**: Parse `versions[0]['created']` with format `'%a, %d %b %Y %H:%M:%S GMT'`
- **Publication year**: Extract from `journal-ref` using regex `r'\b(19[5-9]\d|20[0-4]\d)\b'` (take last match)
- **Publication timing classification**:
  - `pub_year < submit_year` → published before arXiv submission
  - `pub_year == submit_year` → same-year publication
  - `pub_year > submit_year` → published after arXiv submission
- **Author count**: `len(authors_parsed)` (parsed JSON array, not the raw `authors` string)
- **Primary category**: First token of space-separated `categories` string
- **Broad category mapping**: `cs*` → CS, `math*` → Math, `cond-mat/astro-ph/hep/gr-qc/quant-ph` → Physics, etc.

**Output**: A structured JSON file (~15 MB) with all 13 dimensions of aggregated statistics, directly consumable by visualization and report generation.

**Full dimension reference**: See `references/analysis_dimensions.md` for detailed schema, parsing logic, and memory management notes.

### Phase 2: Visualization and Report Generation (Parallel)

Once the analysis JSON is produced, generate deliverables in parallel:

**2A. Interactive Dashboard** (ECharts):
- Self-contained HTML with inline CSS + JS
- ECharts CDN: `https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js`
- 15-20 chart modules: KPI cards, time trends, publication timing pie, dual-axis combo charts, horizontal bar charts, radar/rose charts, seasonality, growth prediction
- Dark academic theme (#0d1b2a background), responsive CSS Grid layout
- All data hardcoded into HTML (no external data dependency)

**2B. Analysis Report** (HTML):
- Self-contained HTML with inline CSS
- Structure: Executive summary → Data overview → Core findings (per dimension) → Limitations → Conclusions
- Each dimension: "Data conclusion" + "Deep interpretation" dual-section format
- Warning boxes for data limitations (survival bias, journal-ref parsing caveats)
- Deep blue theme (#1a3a5c) + gold accent (#c9a227)

### Phase 3: Assembly

Combine dashboard + report + analysis JSON + scripts into final deliverables. Present via `present_files`.

## Key Data Limitations to Document

1. **Survival bias**: Recent papers haven't had time to be published → publication rate appears to decline over time (not a real trend)
2. **Journal-ref parsing**: ~481K published papers have unparseable years; regex may misidentify non-year 4-digit numbers
3. **Publication definition**: `doi` OR `journal-ref` non-null is a lower-bound estimate; some published papers may lack both fields
4. **Dataset freshness**: The Kaggle/HF snapshot is updated periodically, not real-time; may lag by weeks/months
5. **Author disambiguation**: `authors_parsed` provides structured names but doesn't resolve identity (same person, different spellings)
6. **Category evolution**: arXiv category taxonomy has changed over 40 years; some historical categories may be deprecated

## Python Environment

- **Interpreter**: Use the managed Python venv at `/Users/guoqiangliang/.workbuddy/binaries/python/envs/default/bin/python3`
- **Required packages**: `pyarrow`, `pandas`, `numpy`, `huggingface_hub`
- **Install**: `/Users/guoqiangliang/.workbuddy/binaries/python/envs/default/bin/pip install pyarrow pandas numpy huggingface_hub`

## Team Orchestration

When operating as the AI Data Copilot team (智数分析专家团), use this orchestration:

1. **Phase 1 (serial)**: Dispatch `data-scientist` to download + analyze data
2. **Phase 2 (parallel)**: Dispatch `dashboard-designer` and `report-composer` simultaneously
3. **Phase 3**: Lead assembles and presents deliverables

Team naming: `copilot-arxiv-full`

## Resources

### scripts/
- `download_arxiv_dataset.py` — Downloads all Parquet shards from HuggingFace (no credentials needed)
- `analyze_arxiv_full.py` — Parameterized full-dataset analysis script (13 dimensions, memory-safe chunked processing)

### references/
- `analysis_dimensions.md` — Detailed reference for all 13 analysis dimensions, including field parsing logic, memory management strategy, output JSON structure, and data source alternatives
